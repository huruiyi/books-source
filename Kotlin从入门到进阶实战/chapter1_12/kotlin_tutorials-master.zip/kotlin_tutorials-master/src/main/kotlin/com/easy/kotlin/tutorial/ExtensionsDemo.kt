package com.easy.kotlin.tutorial

import com.easy.kotlin.firstChar
import com.easy.kotlin.lastChar

fun main(args: Array<String>) {
    val str = "abc"
    str.firstChar()
    str.lastChar()
}