package com.easy.kotlin

data class PersonKotlin(val id: Int, val name: String)
