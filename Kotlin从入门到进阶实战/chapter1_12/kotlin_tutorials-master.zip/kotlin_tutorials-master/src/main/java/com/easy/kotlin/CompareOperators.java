/*
 * Copyright (c) 2017. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

package com.easy.kotlin;

import java.math.BigDecimal;

public class CompareOperators {
    public static void main(String[] args) {
        int x = 1;
        int y = 1;

        boolean b1 = x > y;
        boolean b2 = x < y;
        boolean b3 = x >= y;
        boolean b4 = x <= y;
        boolean b5 = x == y;
        boolean b6 = x != y;

        System.out.println(b1);
        System.out.println(b2);
        System.out.println(b3);
        System.out.println(b4);
        System.out.println(b5);
        System.out.println(b6);

        BigDecimal bd1 = BigDecimal.ONE;
        BigDecimal bd2 = BigDecimal.ONE;
        //boolean b7 = bd1 > bd2;








    }
}



