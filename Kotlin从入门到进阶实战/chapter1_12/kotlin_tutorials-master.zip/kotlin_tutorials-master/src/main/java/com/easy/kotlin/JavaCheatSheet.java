package com.easy.kotlin;

public class JavaCheatSheet {
    public static void main(String[] args) {
        System.out.println("Hello,World");
    }
}


