package com.easy.kotlin.picturecrawler.dto

data class ImageCategoryAndUrl(val category: String, val url: String)
