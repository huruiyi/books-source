INSERT INTO another_person (name, age) VALUES ('wyf', 35);
INSERT INTO another_person (name, age) VALUES ('foo', 34);
INSERT INTO another_person (name, age) VALUES ('bar', 33);
INSERT INTO another_person (name, age) VALUES ('www', 32);