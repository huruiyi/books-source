package top.wisely.springfundamentals.beans.pojo;

public class WindowsService {
    public void show(){
        System.out.println("当前是Windows系统");
    }
}
