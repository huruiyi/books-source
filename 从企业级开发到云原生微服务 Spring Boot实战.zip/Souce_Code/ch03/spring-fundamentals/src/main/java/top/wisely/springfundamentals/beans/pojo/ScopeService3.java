package top.wisely.springfundamentals.beans.pojo;

public class ScopeService3 {
}
