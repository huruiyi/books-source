package top.wisely.springfundamentals.beans.annotated;

import org.springframework.stereotype.Service;

@Service
public class AsyncTaskService {
}
