package top.wisely.intellijspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IntellijSpringBootApplicationTests {

    @Test
    void contextLoads() {
    }

}
