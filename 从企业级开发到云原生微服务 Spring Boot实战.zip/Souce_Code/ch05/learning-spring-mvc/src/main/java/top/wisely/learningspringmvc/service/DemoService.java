package top.wisely.learningspringmvc.service;

import org.springframework.stereotype.Service;

@Service
public class DemoService {
    public String sayHello(){
        return "Hello World";
    }
}
