package top.wisely.functionalprogramming;

public enum  Gender {
    MALE, FEMALE
}
