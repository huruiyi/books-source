package top.wisely.springbootindepth.service;

import org.springframework.stereotype.Service;

@Service
public class DemoService {
    public String doSomething(){
        return "top.wisely.springbootindepth包被扫描到了aaa";
    }
}
