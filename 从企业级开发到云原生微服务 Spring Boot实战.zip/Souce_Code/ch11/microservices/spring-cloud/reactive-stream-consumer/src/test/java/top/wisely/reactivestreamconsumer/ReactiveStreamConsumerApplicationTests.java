package top.wisely.reactivestreamconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveStreamConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
