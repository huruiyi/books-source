package top.wisely.learningspringbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSpringBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
