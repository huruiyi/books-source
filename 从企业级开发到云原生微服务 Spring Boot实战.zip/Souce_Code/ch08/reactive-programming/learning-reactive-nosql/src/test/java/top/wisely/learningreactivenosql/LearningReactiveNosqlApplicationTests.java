package top.wisely.learningreactivenosql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningReactiveNosqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
