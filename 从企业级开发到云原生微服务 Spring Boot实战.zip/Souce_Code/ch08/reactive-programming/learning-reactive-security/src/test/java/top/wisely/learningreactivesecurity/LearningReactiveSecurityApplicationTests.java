package top.wisely.learningreactivesecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningReactiveSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
