package top.wisely.learningkafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
