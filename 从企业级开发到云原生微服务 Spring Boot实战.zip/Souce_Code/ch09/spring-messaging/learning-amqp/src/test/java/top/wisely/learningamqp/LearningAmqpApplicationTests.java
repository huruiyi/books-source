package top.wisely.learningamqp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningAmqpApplicationTests {

	@Test
	void contextLoads() {
	}

}
