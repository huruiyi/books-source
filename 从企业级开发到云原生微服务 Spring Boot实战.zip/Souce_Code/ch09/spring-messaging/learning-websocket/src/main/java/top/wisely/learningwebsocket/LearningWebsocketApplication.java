package top.wisely.learningwebsocket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LearningWebsocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(LearningWebsocketApplication.class, args);
	}

}
