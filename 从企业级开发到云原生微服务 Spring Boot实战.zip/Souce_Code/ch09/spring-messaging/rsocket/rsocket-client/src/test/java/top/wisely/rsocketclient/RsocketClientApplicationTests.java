package top.wisely.rsocketclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RsocketClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
