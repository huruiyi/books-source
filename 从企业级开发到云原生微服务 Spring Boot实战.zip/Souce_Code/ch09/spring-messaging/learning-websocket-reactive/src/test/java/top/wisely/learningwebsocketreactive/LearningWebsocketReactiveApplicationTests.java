package top.wisely.learningwebsocketreactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningWebsocketReactiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
