import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'taco-specials',
  templateUrl: 'specials.component.html'
})

export class SpecialsComponent implements OnInit {
  constructor() { }

  ngOnInit() { }
}
