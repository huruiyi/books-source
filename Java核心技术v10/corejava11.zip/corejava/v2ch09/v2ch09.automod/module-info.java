@SuppressWarnings("module")
module v2ch09.automod 
{
   requires commons.csv;
}
