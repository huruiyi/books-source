package com.ghy.www.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContext;

import javax.servlet.http.HttpServletRequest;

@Controller
public class TestController {
    @RequestMapping(value = "login")
    public String login(String username, String password, HttpServletRequest request, RedirectAttributes attr) {
        System.out.println("login run !");

        RequestContext context = new RequestContext(request);

        if (username == null || "".equals(username)) {
            attr.addFlashAttribute("usernameisnull", context.getMessage("usernameisnull"));
        }
        if (password == null || "".equals(password)) {
            attr.addFlashAttribute("passwordisnull", context.getMessage("passwordisnull"));
        }
        return "redirect:/showLogin";
    }

    @RequestMapping(value = "showLogin")
    public String showLogin(HttpServletRequest request) {
        System.out.println("test run !");
        return "showLogin.jsp";
    }
}
