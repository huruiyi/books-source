package com.ghy.www.controller;

import com.ghy.www.exception.LoginException1;
import com.ghy.www.exception.LoginException2;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import java.sql.SQLException;

@Controller
public class TestController {
    @RequestMapping(value = "test1")
    public String test1() {
        System.out.println("public String test1()");
        int i = 10;
        int j = 0;
        int result = i / j;
        return "index.jsp";
    }

    @RequestMapping(value = "test2")
    public String test2() throws Exception {
        System.out.println("public String test2()");
        if (1 == 1) {
            throw new SQLException("SQL语句错误");
        }
        return "index.jsp";
    }

    @RequestMapping(value = "test3")
    public String test3() throws LoginException1 {
        System.out.println("public String test3()");
        if (1 == 1) {
            throw new LoginException1("账号XX登陆失败，请重新登陆!");
        }
        return "index.jsp";
    }

    @RequestMapping(value = "test4")
    public String test4() throws LoginException2 {
        System.out.println("public String test4()");
        if (1 == 1) {
            throw new LoginException2("账号XX登陆失败，请重新登陆!");
        }
        return "index.jsp";
    }
}