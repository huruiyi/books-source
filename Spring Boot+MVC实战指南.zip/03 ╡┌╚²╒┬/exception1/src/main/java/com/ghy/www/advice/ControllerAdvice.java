package com.ghy.www.advice;

import com.ghy.www.exception.LoginException1;
import com.ghy.www.exception.LoginException2;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@org.springframework.web.bind.annotation.ControllerAdvice
public class ControllerAdvice {
    @ExceptionHandler(value = Exception.class)
    public ModelAndView processException(Exception ex) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("ex", ex);
        mav.setViewName("errorPage.jsp");
        return mav;
    }

    @ExceptionHandler(value = SQLException.class)
    public ModelAndView processSQLException(SQLException ex) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("ex", ex);
        mav.setViewName("sqlerror.jsp");
        return mav;
    }

    @ExceptionHandler(value = LoginException1.class)
    public ModelAndView processLoginException1(LoginException1 ex) {
        ModelAndView mav = new ModelAndView();
        mav.addObject("ex", ex);
        mav.setViewName("loginException1.jsp");
        return mav;
    }

    @ExceptionHandler(value = LoginException2.class)
    @ResponseBody
    public Map processLoginException2(LoginException2 ex) {
        Map map = new HashMap();
        map.put("controllerName", "UserinfoController");
        map.put("message", ex.getMessage());
        return map;
    }
}
