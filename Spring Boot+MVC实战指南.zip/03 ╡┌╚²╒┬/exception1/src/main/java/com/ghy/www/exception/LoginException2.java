package com.ghy.www.exception;

public class LoginException2 extends Exception {
    public LoginException2(String message) {
        super(message);
    }
}