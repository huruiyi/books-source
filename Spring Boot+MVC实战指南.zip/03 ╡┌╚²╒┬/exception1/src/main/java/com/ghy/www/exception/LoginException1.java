package com.ghy.www.exception;

public class LoginException1 extends Exception {
    public LoginException1(String message) {
        super(message);
    }
}