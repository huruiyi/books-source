package com.ghy.www.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Enumeration;

@Controller
public class TestController {
    @RequestMapping(value = "test")
    public String test(HttpSession session) {
        System.out.println("test run !");
        Enumeration enum1 = session.getAttributeNames();
        while (enum1.hasMoreElements()) {
            System.out.println("key=" + enum1.nextElement());
        }
        return "test.jsp";
    }
}
