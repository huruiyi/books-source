package com.ghy.www.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class TestController {
    @GetMapping(value = "get")
    @ResponseBody
    public String get(String username) {
        System.out.println("get username=" + username);
        return "getReturn";
    }

    @PostMapping(value = "post")
    @ResponseBody
    public String post(String username) {
        System.out.println("post username=" + username);
        return "postReturn";
    }

    @PutMapping(value = "put")
    @ResponseBody
    public String put(String username) {
        System.out.println("put username=" + username);
        return "putReturn";
    }

    @DeleteMapping(value = "delete")
    @ResponseBody
    public String delete(String username) {
        System.out.println("delete username=" + username);
        return "deleteReturn";
    }
}
