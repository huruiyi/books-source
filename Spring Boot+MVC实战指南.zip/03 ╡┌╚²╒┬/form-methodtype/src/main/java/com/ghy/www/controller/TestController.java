package com.ghy.www.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

@Controller
public class TestController {
    @GetMapping(value = "get")
    public String get(String username) {
        System.out.println("get username=" + username);
        return "index.jsp";
    }

    @PostMapping(value = "post")
    public String post(String username) {
        System.out.println("post username=" + username);
        return "redirect:/get?username=getValue";
    }

    @PutMapping(value = "put")
    public String put(String username) {
        System.out.println("put username=" + username);
        return "redirect:/get?username=getValue";
    }

    @DeleteMapping(value = "delete")
    public String delete(String username) {
        System.out.println("delete username=" + username);
        return "redirect:/get?username=getValue";
    }
}
