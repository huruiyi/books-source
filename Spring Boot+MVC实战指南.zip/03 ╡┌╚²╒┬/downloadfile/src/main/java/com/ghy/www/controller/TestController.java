package com.ghy.www.controller;

import org.apache.commons.io.IOUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;

@Controller
public class TestController {
    @RequestMapping(value = "downloadFile")
    public void testA(String fileName, HttpServletRequest request, HttpServletResponse response)
            throws UnsupportedEncodingException {
        try {
            System.out.println(fileName);
            String downPath = request.getSession().getServletContext().getRealPath("/");
            System.out.println(downPath + fileName);
            File downloadFile = new File(downPath + fileName);
            response.setContentType("application/octet-stream;");
            String useragent = request.getHeader("User-Agent").toLowerCase();
            System.out.println(useragent);
            if (useragent.contains("wow64")) {
                System.out.println("IE");
                // 1.IE浏览器UTF-8
                response.setHeader("Content-Disposition", "attachment;filename="
                        + java.net.URLEncoder.encode(fileName, "utf-8").replaceAll("\\+", "%20"));
                // replaceAll("\\+", "%20");的作用是处理空格
            } else {
                // 2.其他浏览器
                System.out.println("NOT IE");
                response.setHeader("Content-Disposition", "attachment;filename*=utf-8'zh_cn';filename="
                        + java.net.URLEncoder.encode(fileName, "utf-8").replaceAll("\\+", "%20"));
            }
            response.setHeader("Content-Length", String.valueOf(downloadFile.length()));
            FileInputStream fis = new FileInputStream(downloadFile);
            ServletOutputStream out = response.getOutputStream();
            IOUtils.copyLarge(fis, out);
            out.flush();
            out.close();
            fis.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

