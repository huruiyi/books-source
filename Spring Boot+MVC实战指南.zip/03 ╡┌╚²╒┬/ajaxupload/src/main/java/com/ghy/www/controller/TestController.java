package com.ghy.www.controller;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;

@Controller
public class TestController {
    @RequestMapping("/upload")
    public String upload(MultipartHttpServletRequest request) throws IOException {
        System.out.println(request.getParameter("username"));
        String uploadPath = request.getServletContext().getRealPath("/upload");
        System.out.println(uploadPath);

        MultipartFile uploadFile = request.getFile("uploadFile");
        String fileName = uploadFile.getOriginalFilename();
        InputStream inputStream = uploadFile.getInputStream();

        File newFile = new File(uploadPath, fileName);
        FileUtils.copyInputStreamToFile(inputStream, newFile);

        return "index.jsp";
    }
}

