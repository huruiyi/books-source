package com.ghy.www.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import java.util.Locale;

@Controller
public class TestController {
    @RequestMapping(value = "test")
    public String test(HttpServletRequest request) {
        Locale locale = request.getLocale();
        System.out.println("getLanguage=" + locale.getLanguage());
        return "test.jsp";
    }
}
