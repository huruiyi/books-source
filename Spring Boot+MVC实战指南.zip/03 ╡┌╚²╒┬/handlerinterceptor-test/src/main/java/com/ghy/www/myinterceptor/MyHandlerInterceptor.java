package com.ghy.www.myinterceptor;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class MyHandlerInterceptor implements HandlerInterceptor {
    // 在调用控制层方法之前执行
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        System.out.println("preHandle：");
        System.out.println("request=" + request + " getServletPath=" + request.getServletPath());
        System.out.println("response=" + response);
        System.out.println("handler=" + handler.getClass().getName());
        System.out.println();
        return false;
    }

    // 调用控制层方法没有出现异常之后执行
    // 调用控制层方法出现异常之后不执行
    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           ModelAndView modelAndView) throws Exception {
        HandlerInterceptor.super.postHandle(request, response, handler, modelAndView);
        System.out.println("postHandle：");
        System.out.println("request=" + request + " getServletPath=" + request.getServletPath());
        System.out.println("response=" + response);
        System.out.println("handler=" + handler.getClass().getName());
        System.out.println("modelAndView=" + modelAndView);
        System.out.println();
    }

    // 不管调用控制层方法没有有出现异常都执行
    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
            throws Exception {
        HandlerInterceptor.super.afterCompletion(request, response, handler, ex);
        System.out.println("afterCompletion：");
        System.out.println("request=" + request + " getServletPath=" + request.getServletPath());
        System.out.println("response=" + response);
        System.out.println("handler=" + handler.getClass().getName());
        System.out.println("ex=" + ex);
    }
}