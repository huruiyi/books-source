package com.ghy.www.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TestController {
    @RequestMapping(value = "/test1")
    @ResponseBody
    public String test1() {
        System.out.println("public String test1()");
        System.out.println();
        return "i am test1 string";
    }

    @RequestMapping(value = "/test2")
    public ModelAndView test2() {
        System.out.println("public String test2()");
        System.out.println();
        ModelAndView view = new ModelAndView();
        view.setViewName("welcome.jsp");
        return view;
    }

    @RequestMapping(value = "/test3")
    public ModelAndView test3() {
        System.out.println("public String test3()");
        System.out.println();
        String username = null;
        username.toString();// 出现异常
        ModelAndView view = new ModelAndView();
        view.setViewName("welcome.jsp");
        return view;
    }
}
