package com.ghy.www.test;

import java.util.Locale;

public class Test {
    public static void main(String[] args) {
        Locale[] localeArray = Locale.getAvailableLocales();
        for (int i = 0; i < localeArray.length; i++) {
            Locale locale = localeArray[i];
            System.out.println(locale.getCountry() + " " + locale.getLanguage());
        }
    }
}
