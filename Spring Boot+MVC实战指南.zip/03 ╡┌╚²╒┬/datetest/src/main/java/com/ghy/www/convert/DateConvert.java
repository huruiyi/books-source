package com.ghy.www.convert;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;

@Component
public class DateConvert implements Converter<String, Date> {
    @Override
    public Date convert(String stringDate) {
        System.out.println("进入了DateConvert中的public Date convert(String stringDate)方法");
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy/MM/dd");
        SimpleDateFormat simpleDateFormat3 = new SimpleDateFormat("yyyy年MM月dd日");

        SimpleDateFormat[] formatArray = new SimpleDateFormat[]{simpleDateFormat1, simpleDateFormat2,
                simpleDateFormat3};
        boolean formatResult = false;
        for (int i = 0; i < formatArray.length; i++) {
            try {
                Date newDate = formatArray[i].parse(stringDate);
                formatResult = true;
                return newDate;
            } catch (Exception e) {
            }
        }
        if (formatResult == false) {
            System.err.println("stringDate=" + stringDate + "，日期格式错误！-------------------------");
        }
        return null;
    }
}