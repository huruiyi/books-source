package com.ghy.www.entity;

import java.util.Date;

public class Userinfo {
    private String username;
    private Date date;

    public Userinfo() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
