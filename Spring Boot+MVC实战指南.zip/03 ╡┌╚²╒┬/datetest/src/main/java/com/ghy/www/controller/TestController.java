package com.ghy.www.controller;

import com.ghy.www.entity.Userinfo;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.Date;

@Controller
public class TestController {
    @RequestMapping("/test1")
    public String test1(Date date) {
        System.out.println("test1 date=" + date);
        return "index.jsp";
    }

    @RequestMapping("/test2")
    public String test1(Userinfo userinfo) {
        System.out.println("test2 " + userinfo.getUsername() + " " + userinfo.getDate());
        return "index.jsp";
    }

    @RequestMapping("/test3")
    @ResponseBody
    public Userinfo test3() {
        Userinfo userinfo = new Userinfo();
        userinfo.setUsername("返回的账号");
        userinfo.setDate(new Date());
        return userinfo;
    }

    @RequestMapping("/test4")
    @ResponseBody
    public Date test4() {
        return new Date();
    }
}

