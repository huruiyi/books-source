package com.ghy.www.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TestController {
    @RequestMapping(value = "helloWorld")
    public String helloWorldMethod(@RequestParam("username") String u) {
        System.out.println("hello " + u);
        return "hello.jsp";
    }
}

