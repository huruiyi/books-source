package com.ghy.www.service;

public interface ISaveDBService {
    void saveMethod();
}
