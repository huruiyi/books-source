package com.ghy.www.service;

public class SaveDBService implements ISaveDBService {
    @Override
    public void saveMethod() {
        System.out.println("将数据保存进DB数据库");
    }
}
