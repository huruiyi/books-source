package com.ghy.www.test1;

import com.ghy.www.service.ISaveDBService;
import com.ghy.www.service.SaveDBService;

public class Test {
    private ISaveDBService service = new SaveDBService();

    public ISaveDBService getService() {
        return service;
    }

    public void setService(ISaveDBService service) {
        this.service = service;
    }

    public static void main(String[] args) {
        Test test = new Test();
        test.getService().saveMethod();
    }
}
