package com.ghy.www.test1;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import java.io.FileWriter;
import java.io.IOException;

public class Writer {

    public static void main(String[] args) {
        try {
            Document document = DocumentHelper.createDocument();
            Element mymvcElement = document.addElement("mymvc");
            Element actionsElement = mymvcElement.addElement("actions");
            //
            Element listActionElement = actionsElement.addElement("action");
            listActionElement.addAttribute("name", "list");
            listActionElement.addAttribute("class", "controller.List");

            Element toListJSPResultElement = listActionElement
                    .addElement("result");
            toListJSPResultElement.addAttribute("name", "toListJSP");
            toListJSPResultElement.setText("/list.jsp");

            Element toShowUserinfoListResultElement = listActionElement
                    .addElement("result");
            toShowUserinfoListResultElement.addAttribute("name",
                    "toShowUserinfoList");
            toShowUserinfoListResultElement.addAttribute("type", "redirect");
            toShowUserinfoListResultElement.setText("showUserinfoList.ghy");
            //

            Element showUserinfoListActionElement = actionsElement
                    .addElement("action");
            showUserinfoListActionElement.addAttribute("name",
                    "showUserinfoList");
            showUserinfoListActionElement.addAttribute("class",
                    "controller.ShowUserinfoList");

            Element toShowUserinfoListJSPResultElement = showUserinfoListActionElement
                    .addElement("result");
            toShowUserinfoListJSPResultElement.addAttribute("name",
                    "toShowUserinfoListJSP");
            toShowUserinfoListResultElement.setText("/showUserinfoList.jsp");
            //

            OutputFormat format = OutputFormat.createPrettyPrint();
            XMLWriter writer = new XMLWriter(new FileWriter("ghy.xml"), format);
            writer.write(document);
            writer.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}
