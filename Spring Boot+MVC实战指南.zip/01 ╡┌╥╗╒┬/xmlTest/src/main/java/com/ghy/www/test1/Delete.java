package com.ghy.www.test1;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class Delete {

    public static void main(String[] args) throws IOException {
        try {
            SAXReader reader = new SAXReader();
            Document document = reader.read(reader.getClass().getResourceAsStream("/struts.xml"));
            Element mymvcElement = document.getRootElement();
            Element actionsElement = mymvcElement.element("actions");
            List<Element> actionList = actionsElement.elements("action");
            for (int i = 0; i < actionList.size(); i++) {
                Element actionElement = actionList.get(i);
                List<Element> resultList = actionElement.elements("result");
                Element resultElement = null;
                boolean isFindNode = false;
                for (int j = 0; j < resultList.size(); j++) {
                    resultElement = resultList.get(j);
                    String resultName = resultElement.attribute("name").getValue();
                    if (resultName.equals("toShowUserinfoList")) {
                        isFindNode = true;
                        break;
                    }
                }
                if (isFindNode == true) {
                    actionElement.remove(resultElement);
                }
            }
            OutputFormat format = OutputFormat.createPrettyPrint();
            XMLWriter writer = new XMLWriter(new FileWriter("src\\ghy.xml"), format);
            writer.write(document);
            writer.close();
        } catch (DocumentException e) {
            e.printStackTrace();
        }
    }

}
