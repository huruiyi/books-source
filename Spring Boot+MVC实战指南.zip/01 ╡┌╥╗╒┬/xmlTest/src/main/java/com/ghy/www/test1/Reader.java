package com.ghy.www.test1;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import java.util.List;

public class Reader {
    public static void main(String[] args) {
        try {
            SAXReader reader = new SAXReader();
            Document document = reader.read(reader.getClass()
                    .getResourceAsStream("/struts.xml"));

            Element mymvcElement = document.getRootElement();
            System.out.println(mymvcElement.getName());
            Element actionsElement = mymvcElement.element("actions");
            System.out.println("  " + actionsElement.getName());
            List<Element> actionList = actionsElement.elements("action");
            for (int i = 0; i < actionList.size(); i++) {
                Element actionElement = actionList.get(i);
                System.out.print("    " + actionElement.getName() + " ");
                System.out.print("name="
                        + actionElement.attribute("name").getValue());
                System.out.println("action class="
                        + actionElement.attribute("class").getValue());

                List<Element> resultList = actionElement.elements("result");
                for (int j = 0; j < resultList.size(); j++) {
                    Element resultElement = resultList.get(j);
                    System.out.print("      result name="
                            + resultElement.attribute("name").getValue());
                    Attribute typeAttribute = resultElement.attribute("type");
                    if (typeAttribute != null) {
                        System.out.println(" type=" + typeAttribute.getValue());
                    } else {
                        System.out.println("");
                    }
                    System.out.println("        " + resultElement.getText().trim());
                }
            }
        } catch (DocumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
