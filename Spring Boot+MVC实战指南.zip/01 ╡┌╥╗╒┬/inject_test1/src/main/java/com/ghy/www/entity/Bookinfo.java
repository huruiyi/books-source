package com.ghy.www.entity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.inject.Inject;

@Component
public class Bookinfo {
    @Inject
    public Bookinfo(Userinfo userinfo) {
        System.out.println("public Bookinfo(Userinfo userinfo) userinfo=" + userinfo.hashCode());
    }
}