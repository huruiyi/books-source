package com.ghy.www.entity;

public class A {

    private B b;

    public A() {
    }

    public A(B b) {
        super();
        this.b = b;
    }

    public B getB() {
        return b;
    }

    public void setB(B b) {
        this.b = b;
    }

}

