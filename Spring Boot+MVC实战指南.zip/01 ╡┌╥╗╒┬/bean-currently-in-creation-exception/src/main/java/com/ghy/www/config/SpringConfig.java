package com.ghy.www.config;

import com.ghy.www.entity.A;
import com.ghy.www.entity.B;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
    @Bean
    public A getA(B b) {
        return new A(b);
    }

    @Bean
    public B getB(A a) {
        return new B(a);
    }
}
