package com.ghy.www.entity;

public class B {
    private A a;

    public B() {
    }

    public B(A a) {
        super();
        this.a = a;
    }

    public A getA() {
        return a;
    }

    public void setA(A a) {
        this.a = a;
    }

}
