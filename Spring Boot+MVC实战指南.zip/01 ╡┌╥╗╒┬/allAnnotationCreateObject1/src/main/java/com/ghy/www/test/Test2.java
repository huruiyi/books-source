package com.ghy.www.test;

import com.ghy.www.entity.Userinfo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test2 {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext("com.ghy.www.javaconfig");
        context.getBean(Userinfo.class);
    }
}