package com.ghy.www.test;

import com.ghy.www.config.AllConfig;
import com.ghy.www.config.SpringConfig1;
import com.ghy.www.entity.Bookinfo;
import com.ghy.www.entity.Userinfo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test1 {
    public static void main(String[] args) {
        ApplicationContext context1 = new AnnotationConfigApplicationContext(AllConfig.class);
        System.out.println("context1=" + context1.getBean(Bookinfo.class).hashCode());
        System.out.println("context2=" + context1.getBean(Userinfo.class).hashCode());
    }
}
