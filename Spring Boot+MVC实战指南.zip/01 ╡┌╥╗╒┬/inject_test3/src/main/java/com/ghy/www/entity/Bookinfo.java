package com.ghy.www.entity;

import org.springframework.stereotype.Component;

import javax.inject.Inject;

@Component
public class Bookinfo {
    @Inject
    private Userinfo userinfo;

    public Userinfo getUserinfo() {
        return userinfo;
    }

    public void setUserinfo(Userinfo userinfo) {
        this.userinfo = userinfo;
    }
}
