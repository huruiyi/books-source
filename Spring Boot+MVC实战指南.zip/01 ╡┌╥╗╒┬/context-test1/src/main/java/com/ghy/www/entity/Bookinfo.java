package com.ghy.www.entity;

public class Bookinfo {
    public Bookinfo() {
        System.out.println("public Bookinfo() " + this.hashCode());
    }
}
