package com.ghy.www.config;

import com.ghy.www.entity.Userinfo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig2 {
    @Bean
    public Userinfo createUserinfo() {
        Userinfo userinfo = new Userinfo();
        System.out.println("getUserinfo userinfo=" + userinfo.hashCode());
        return userinfo;
    }
}

