package com.ghy.www.a.b;

import org.springframework.stereotype.Component;

@Component
public class B2 {
    public B2() {
        System.out.println("public B2()");
    }
}
