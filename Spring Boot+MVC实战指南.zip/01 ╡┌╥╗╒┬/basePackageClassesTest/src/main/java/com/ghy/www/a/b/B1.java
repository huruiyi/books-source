package com.ghy.www.a.b;
import org.springframework.stereotype.Component;

@Component
public class B1 {
    public B1() {
        System.out.println("public B1()");
    }
}
