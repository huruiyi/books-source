package com.ghy.www.a;

import org.springframework.stereotype.Component;

@Component
public class A {
    public A() {
        System.out.println("public A()");
    }
}
