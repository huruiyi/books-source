package com.ghy.www.javaconfig;

import com.ghy.www.a.b.B1;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.Date;

@Configuration
@ComponentScan(basePackageClasses = {B1.class})
public class SpringConfig {
    @Bean
    public Date createDate() {
        Date nowDate = new Date();
        System.out.println("createDate " + nowDate.hashCode());
        return nowDate;
    }
}
