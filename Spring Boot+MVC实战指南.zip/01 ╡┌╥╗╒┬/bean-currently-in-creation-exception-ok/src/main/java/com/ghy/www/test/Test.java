package com.ghy.www.test;

import com.ghy.www.entity.A;
import com.ghy.www.entity.B;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext("com.ghy.www");
        System.out.println(context.getBean(A.class));
        System.out.println(context.getBean(B.class));
    }
}
