package com.ghy.www.service;

public interface IUserinfoService {
    public void save();
}