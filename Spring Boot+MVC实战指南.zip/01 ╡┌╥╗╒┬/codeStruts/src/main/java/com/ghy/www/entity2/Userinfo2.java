package com.ghy.www.entity2;

import org.springframework.stereotype.Component;

@Component
public class Userinfo2 {
    public Userinfo2() {
        System.out.println("public Userinfo2()");
    }
}

