package com.ghy.www.entity1;

import org.springframework.stereotype.Component;

@Component
public class Userinfo1 {
    public Userinfo1() {
        System.out.println("public Userinfo1()");
    }
}
