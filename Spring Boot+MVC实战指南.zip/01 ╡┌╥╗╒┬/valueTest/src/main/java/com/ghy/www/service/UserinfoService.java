package com.ghy.www.service;

import com.ghy.www.entity.Userinfo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service(value = "userinfoService")
public class UserinfoService {

    @Value("UserinfoService常<量>值&")
    private String username;

    private Userinfo userinfo = new Userinfo();

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public Userinfo getUserinfo() {
        return userinfo;
    }

    public void setUserinfo(Userinfo userinfo) {
        this.userinfo = userinfo;
    }

}

