package com.ghy.www.entity;

public class Userinfo {
    public Userinfo() {
        System.out.println("public Userinfo() " + this.hashCode());
    }
}
