package com.ghy.www.test;

import com.ghy.www.entity.Userinfo;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@ComponentScan(basePackages = {"com.ghy.www.test", "com.ghy.www.service"})
@PropertySource(value = {"classpath:db.properties"})
@Configuration
public class Test {

    @Value("#{userinfoService.userinfo}")
    public Userinfo userinfo;

    @Value("#{userinfoService.username}")
    public String injectStringValue;

    @Value("${dbdriver}")
    public String a;
    @Value("${dburl}")
    public String b;
    @Value("${dbusername}")
    public String c;
    @Value("${dbpassword}")
    public String d;

    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(Test.class);
        Test test = context.getBean(Test.class);
        System.out.println("userinfo=" + test.userinfo.hashCode());
        System.out.println("injectStringValue=" + test.injectStringValue);
        System.out.println("a=" + test.a);
        System.out.println("b=" + test.b);
        System.out.println("c=" + test.c);
        System.out.println("d=" + test.d);
    }
}

