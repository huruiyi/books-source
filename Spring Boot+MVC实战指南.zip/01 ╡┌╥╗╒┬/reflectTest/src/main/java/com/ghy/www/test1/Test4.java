package com.ghy.www.test1;

import com.ghy.www.entity.Userinfo;

public class Test4 {
    public static void main(String[] args) throws ClassNotFoundException {
        Class class1 = Userinfo.class;
        Class class2 = new Userinfo().getClass();
        Class class3 = Userinfo.class.getClassLoader().loadClass("com.ghy.www.entity.Userinfo");
        Class class4 = Class.forName("com.ghy.www.entity.Userinfo");
        System.out.println(class1.hashCode());
        System.out.println(class2.hashCode());
        System.out.println(class3.hashCode());
        System.out.println(class4.hashCode());
    }

}
