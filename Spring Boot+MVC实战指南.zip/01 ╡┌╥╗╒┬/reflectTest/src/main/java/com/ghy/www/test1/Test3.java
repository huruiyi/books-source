package com.ghy.www.test1;

import java.io.IOException;
import java.io.InputStream;

public class Test3 {
    public static void main(String[] args) throws IOException {
        byte[] byteArray = new byte[1000];
        InputStream inputStream = Test3.class.getResourceAsStream("/createClassName.txt");
        int readLength = inputStream.read(byteArray);
        String createClassName = new String(byteArray, 0, readLength);
        System.out.println(createClassName);
        // new createClassName;
        // new createClassName();
        // new "com.ghy.www.entity.Userinfo";
        // new "com.ghy.www.entity.Userinfo" ();
    }
}
