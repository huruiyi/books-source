package com.ghy.www.test1;

import com.ghy.www.entity.Userinfo;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class Test5 {
    public static void main(String[] args) {
        Class userinfoClass = Userinfo.class;
        // 属性列表
        Field[] a = userinfoClass.getDeclaredFields();
        System.out.println(a.length);
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i].getName());
        }
        System.out.println();
        // 构造列表
        Constructor[] b = userinfoClass.getConstructors();
        System.out.println(b.length);
        System.out.println();
        // 方法列表
        Method[] c = userinfoClass.getDeclaredMethods();
        System.out.println(c.length);
        for (int i = 0; i < c.length; i++) {
            System.out.println(c[i].getName());
        }
    }
}
