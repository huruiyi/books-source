package com.ghy.www.entity;

public class Userinfo {

    private long id;
    private String username;
    private String password;

    public Userinfo() {
        System.out.println("public Userinfo()");
    }

    public Userinfo(long id) {
        super();
        this.id = id;
    }

    public Userinfo(long id, String username) {
        super();
        this.id = id;
        this.username = username;
    }

    public Userinfo(long id, String username, String password) {
        super();
        this.id = id;
        this.username = username;
        this.password = password;
        System.out.println("public Userinfo(long id, String username, String password)");
        System.out.println(id + " " + username + " " + password);

    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void test() {
        System.out.println("public void test1()");
    }

    public void test(String address) {
        System.out.println("public void test2(String address) address=" + address);
    }

    public String test(int age) {
        System.out.println("public String test3(int age) age=" + age);
        return "我是返回值";
    }
}

