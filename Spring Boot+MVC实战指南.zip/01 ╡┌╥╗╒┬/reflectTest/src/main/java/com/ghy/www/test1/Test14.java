package com.ghy.www.test1;

import com.ghy.www.objectfactory.OneInstance;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Test14 {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InstantiationException,
            IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException,
            IllegalArgumentException, InvocationTargetException {
        Class classRef = Class.forName("com.ghy.www.objectfactory.OneInstance");
        Constructor c = classRef.getDeclaredConstructor();
        c.setAccessible(true);
        OneInstance one1 = (OneInstance) c.newInstance();
        OneInstance one2 = (OneInstance) c.newInstance();
        System.out.println(one1);
        System.out.println(one2);
    }
}
