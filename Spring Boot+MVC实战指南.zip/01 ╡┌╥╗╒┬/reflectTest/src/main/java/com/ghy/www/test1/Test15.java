package com.ghy.www.test1;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Test15 {
    public void testMethod(String username) {
        System.out.println("public String testMethod(String username)");
        System.out.println(username);
    }

    public void testMethod(String username, String password) {
        System.out.println("public String testMethod(String username, String password)");
        System.out.println(username + " " + password);
    }

    public static void main(String[] args)
            throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException,
            SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {
        Class class15Class = Test15.class;
        Object object = class15Class.newInstance();
        Method method1 = class15Class.getDeclaredMethod("testMethod", String.class);
        Method method2 = class15Class.getDeclaredMethod("testMethod", String.class, String.class);
        method1.invoke(object, "法国");
        method2.invoke(object, "中国", "中国人");
    }
}
