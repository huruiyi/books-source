package com.ghy.www.test1;

import com.ghy.www.entity.Userinfo;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Test8 {
    public static void main(String[] args)
            throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException,
            SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {
        String newObjectName = "com.ghy.www.entity.Userinfo";
        Class class4 = Class.forName(newObjectName);
        Constructor constructor1 = class4.getDeclaredConstructor();
        Userinfo userinfo1 = (Userinfo) constructor1.newInstance();
        Userinfo userinfo2 = (Userinfo) constructor1.newInstance();
        Userinfo userinfo3 = (Userinfo) constructor1.newInstance();
        System.out.println(userinfo1.hashCode());
        System.out.println(userinfo2.hashCode());
        System.out.println(userinfo3.hashCode());
    }
}
