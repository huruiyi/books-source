package com.ghy.www.test1;

import com.ghy.www.entity.Userinfo;

public class Test6 {
    public static void main(String[] args)
            throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        // 本实验不用new来创建对象，原理就是使用反射技术！
        String newObjectName = "com.ghy.www.entity.Userinfo";
        Class class4 = Class.forName(newObjectName);
        // newInstance开始创建对象
        Userinfo userinfo = (Userinfo) class4.newInstance();
        userinfo.setUsername("美国");
        System.out.println(userinfo.getUsername());
    }
}
