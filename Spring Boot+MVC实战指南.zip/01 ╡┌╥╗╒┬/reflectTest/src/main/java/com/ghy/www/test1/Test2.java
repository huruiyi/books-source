package com.ghy.www.test1;

import java.io.IOException;
import java.io.InputStream;

public class Test2 {
    public static void main(String[] args) throws IOException {
        byte[] byteArray = new byte[1000];
        InputStream inputStream = Test2.class.getResourceAsStream("/createClassName.txt");
        int readLength = inputStream.read(byteArray);
        String createClassName = new String(byteArray, 0, readLength);
        System.out.println(createClassName);
        inputStream.close();
    }
}