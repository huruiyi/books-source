package com.ghy.www.test1;

import com.ghy.www.objectfactory.OneInstance;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class Test13 {
    public static void main(String[] args) throws IOException, ClassNotFoundException, InstantiationException,
            IllegalAccessException, NoSuchFieldException, SecurityException, NoSuchMethodException,
            IllegalArgumentException, InvocationTargetException {
        OneInstance o1 = OneInstance.getOneInstance();
        OneInstance o2 = OneInstance.getOneInstance();
        OneInstance o3 = OneInstance.getOneInstance();
        System.out.println(o1);
        System.out.println(o2);
        System.out.println(o3);
    }
}
