package com.ghy.www.test1;

import com.ghy.www.entity.Userinfo;

import java.lang.reflect.Field;

public class Test7 {
    public static void main(String[] args) throws ClassNotFoundException, InstantiationException,
            IllegalAccessException, NoSuchFieldException, SecurityException {
        String newObjectName = "com.ghy.www.entity.Userinfo";
        Class class4 = Class.forName(newObjectName);
        Userinfo userinfo = (Userinfo) class4.newInstance();

        String fieldName = "username";
        String fieldValue = "法国";
        Field fieldObject = userinfo.getClass().getDeclaredField(fieldName);
        System.out.println(fieldObject.getName());
        fieldObject.setAccessible(true);
        fieldObject.set(userinfo, fieldValue);
        System.out.println(userinfo.getUsername());
        System.out.println(fieldObject.get(userinfo));
    }

}
