package com.ghy.www.objectfactory;

//单例模式
//保证当前进程中只有1个OneInstance类的对象
public class OneInstance {
    private static OneInstance oneInstance;

    private OneInstance() {
    }

    public static OneInstance getOneInstance() {
        if (oneInstance == null) {
            oneInstance = new OneInstance();
        }
        return oneInstance;
    }
}
