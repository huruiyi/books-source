package com.ghy.www.test1;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Test9 {
    public static void main(String[] args)
            throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException,
            SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {
        String newObjectName = "com.ghy.www.entity.Userinfo";
        Class class4 = Class.forName(newObjectName);
        Constructor constructor = class4.getDeclaredConstructor(long.class, String.class, String.class);
        System.out.println(constructor.newInstance(11, "a1", "aa1").hashCode());
        System.out.println(constructor.newInstance(12, "a2", "aa2").hashCode());
        System.out.println(constructor.newInstance(13, "a3", "aa3").hashCode());
        System.out.println(constructor.newInstance(14, "a4", "aa4").hashCode());
    }
}
