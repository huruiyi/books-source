package com.ghy.www.test1;

import com.ghy.www.entity.Userinfo;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Test11 {
    public static void main(String[] args)
            throws ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchFieldException,
            SecurityException, NoSuchMethodException, IllegalArgumentException, InvocationTargetException {
        String newObjectName = "com.ghy.www.entity.Userinfo";
        Class class4 = Class.forName(newObjectName);
        Userinfo userinfo = (Userinfo) class4.newInstance();
        String methodName = "test";
        Method method = class4.getDeclaredMethod(methodName, String.class);
        System.out.println(method.getName());
        method.invoke(userinfo, "我的地址在北京！");
    }
}
