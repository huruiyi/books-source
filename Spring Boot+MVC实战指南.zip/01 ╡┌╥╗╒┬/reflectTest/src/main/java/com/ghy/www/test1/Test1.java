package com.ghy.www.test1;

import com.ghy.www.entity.Userinfo;

public class Test1 {
    public static void main(String[] args) {
        Userinfo userinfo = new Userinfo();
        userinfo.setId(100);
        userinfo.setUsername("中国");
        userinfo.setPassword("中国人");

        System.out.println(userinfo.getId());
        System.out.println(userinfo.getUsername());
        System.out.println(userinfo.getPassword());
    }
}
