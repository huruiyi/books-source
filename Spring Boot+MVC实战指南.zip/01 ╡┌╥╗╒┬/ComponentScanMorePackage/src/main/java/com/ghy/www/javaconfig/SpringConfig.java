package com.ghy.www.javaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.Date;

@Configuration
@ComponentScan(basePackages = {"com.ghy.www.entity1", "com.ghy.www.entity2"})
public class SpringConfig {
    @Bean
    public Date createDate() {
        Date nowDate = new Date();
        System.out.println("createDate " + nowDate.hashCode());
        return nowDate;
    }
}

