package com.ghy.www.javaconfig;

import com.ghy.www.entity.Userinfo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SpringConfig {
    @Bean(name = "userinfo")
    public Userinfo getUserinfo() {
        System.out.println("@Bean creator getUser");
        return new Userinfo();
    }
}
