package com.ghy.www.service;

public interface ISaveService {
    public void saveMethod();
}