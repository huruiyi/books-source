package com.ghy.www.service;

public class SaveDBService implements ISaveService {
    public SaveDBService() {
        System.out.println("Spring通过反射机制来实例化SaveDBService类的对象 " + this);
    }

    @Override
    public void saveMethod() {
        System.out.println("将数据保存进DB数据库");
    }
}