package com.ghy.www.test1;

import com.ghy.www.service.ISaveService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {
    private ISaveService service;
    private String username;

    public ISaveService getService() {
        return service;
    }

    public void setService(ISaveService service) {
        this.service = service;
        System.out.println("setService(ISaveService service) service=" + service);
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        Test test = context.getBean(Test.class);
        test.getService().saveMethod();
        System.out.println(test.getUsername());
    }
}
