package com.ghy.www.service;

public class SaveXMLService implements ISaveService {
    public SaveXMLService() {
        System.out.println("Spring通过反射机制来实例化SaveXMLService类的对象 " + this);
    }

    @Override
    public void saveMethod() {
        System.out.println("将数据保存进XML文件");
    }
}