package com.ghy.www.test;

import com.ghy.www.config.SpringConfig;
import com.ghy.www.entity.Userinfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class Test {
    @Autowired(required = false)
    private Userinfo userinfo;

    public Userinfo getUserinfo() {
        return userinfo;
    }

    public void setUserinfo(Userinfo userinfo) {
        this.userinfo = userinfo;
    }

    public static void main(String[] args) {
        new AnnotationConfigApplicationContext(SpringConfig.class);
    }
}
