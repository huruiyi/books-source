package com.ghy.www.test;

import com.ghy.www.config.SpringConfig;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.Date;

@Component
public class Test {
    @Resource(name = "xxxxxxxxxxxxxxxxxxxxxxx")
    private Date date1;
    @Resource(name = "getDate")
    private Date date2;

    public Date getDate1() {
        return date1;
    }

    public void setDate1(Date date1) {
        this.date1 = date1;
    }

    public Date getDate2() {
        return date2;
    }

    public void setDate2(Date date2) {
        this.date2 = date2;
    }

    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        Test test1 = (Test) context.getBean(Test.class);
        System.out.println("main date1=" + test1.getDate1().hashCode());
        System.out.println("main date2=" + test1.getDate2().hashCode());
    }
}