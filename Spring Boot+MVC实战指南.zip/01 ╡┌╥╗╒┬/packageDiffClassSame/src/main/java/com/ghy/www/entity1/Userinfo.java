package com.ghy.www.entity1;

import org.springframework.stereotype.Component;

@Component(value = "userinfo1")
public class Userinfo {
    public Userinfo() {
        System.out.println("public com.ghy.www.entity1.Userinfo() " + this.hashCode());
    }
}