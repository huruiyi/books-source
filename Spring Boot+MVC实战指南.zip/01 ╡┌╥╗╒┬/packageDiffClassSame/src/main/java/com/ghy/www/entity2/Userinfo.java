package com.ghy.www.entity2;

import org.springframework.stereotype.Component;

@Component(value = "userinfo2")
public class Userinfo {
    public Userinfo() {
        System.out.println("public com.ghy.www.entity2.Userinfo() " + this.hashCode());
    }
}