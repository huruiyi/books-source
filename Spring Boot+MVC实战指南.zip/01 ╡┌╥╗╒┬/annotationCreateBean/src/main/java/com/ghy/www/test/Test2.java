package com.ghy.www.test;

import com.ghy.www.entity.Userinfo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test2 {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
        System.out.println(context.getBean(Userinfo.class).hashCode());
        System.out.println(context.getBean("userinfo").hashCode());
    }
}
