package com.ghy.www.test;

import com.ghy.www.entity.Userinfo1;
import com.ghy.www.entity.Userinfo2;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class Test {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext("com.ghy.www");
        System.out.println(context.getBean(Userinfo1.class).hashCode());
        System.out.println(context.getBean(Userinfo1.class).hashCode());
        System.out.println(context.getBean(Userinfo1.class).hashCode());
        System.out.println();
        System.out.println();
        System.out.println(context.getBean(Userinfo2.class).hashCode());
        System.out.println(context.getBean(Userinfo2.class).hashCode());
        System.out.println(context.getBean(Userinfo2.class).hashCode());
    }
}
