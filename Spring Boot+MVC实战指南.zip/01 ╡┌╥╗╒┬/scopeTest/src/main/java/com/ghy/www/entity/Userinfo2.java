package com.ghy.www.entity;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName = "prototype")
public class Userinfo2 {
    public Userinfo2() {
        System.out.println("public Userinfo2() " + this);
    }
}