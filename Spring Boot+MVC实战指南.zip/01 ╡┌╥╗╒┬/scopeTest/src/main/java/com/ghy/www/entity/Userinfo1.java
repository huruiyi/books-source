package com.ghy.www.entity;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName = "singleton")
public class Userinfo1 {
    public Userinfo1() {
        System.out.println("public Userinfo1() " + this);
    }
}