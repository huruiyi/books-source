package com.ghy.www.config;

import com.ghy.www.entity.Bookinfo;
import com.ghy.www.entity.Userinfo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.ghy.www.entity")
public class SpringConfig {
    @Bean
    public Bookinfo getBookinfo(Userinfo userinfo) {
        System.out.println("public Bookinfo getBookinfo(Userinfo userinfo) userinfo=" + userinfo.hashCode());
        return new Bookinfo(userinfo);
    }
}
