package com.ghy.www.entity;

public class Bookinfo {
    public Bookinfo(Userinfo userinfo) {
        System.out.println("public Bookinfo(Userinfo userinfo) userinfo=" + userinfo.hashCode());
    }
}