package com.ghy.www.entity;

import org.springframework.stereotype.Component;

import javax.inject.Inject;

@Component
public class Bookinfo {
    @Inject
    public void setUserinfo(Userinfo userinfo) {
        System.out.println("public void setUserinfo(Userinfo userinfo) userinfo=" + userinfo.hashCode());
    }
}