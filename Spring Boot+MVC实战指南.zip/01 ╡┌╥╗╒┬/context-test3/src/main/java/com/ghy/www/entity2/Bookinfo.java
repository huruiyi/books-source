package com.ghy.www.entity2;

import org.springframework.stereotype.Component;

@Component("mybean")
public class Bookinfo {
    public Bookinfo() {
        System.out.println("public Bookinfo() " + this.hashCode());
    }
}
