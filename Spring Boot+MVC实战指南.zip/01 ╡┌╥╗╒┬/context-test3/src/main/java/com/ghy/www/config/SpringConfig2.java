package com.ghy.www.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.ghy.www.entity2")
public class SpringConfig2 {
}