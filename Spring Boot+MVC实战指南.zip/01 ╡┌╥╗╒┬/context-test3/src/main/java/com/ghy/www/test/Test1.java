package com.ghy.www.test;

import com.ghy.www.config.SpringConfig1;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test1 {
    public static void main(String[] args) {
        new AnnotationConfigApplicationContext(SpringConfig1.class);
    }
}
