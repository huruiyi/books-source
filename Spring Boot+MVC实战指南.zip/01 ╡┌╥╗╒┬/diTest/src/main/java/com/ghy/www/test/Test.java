package com.ghy.www.test;

import com.ghy.www.entity.Userinfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class Test {
    public Test() {
        System.out.println("public Test() " + this.hashCode());
    }

    @Autowired
    private Userinfo userinfo;

    public Userinfo getUserinfo() {
        return userinfo;
    }

    public void setUserinfo(Userinfo userinfo) {
        this.userinfo = userinfo;
        System.out.println("public void setUserinfo(Userinfo userinfo) userinfo=" + userinfo);
    }

    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext("com.ghy.www");
        Test test = (Test) context.getBean(Test.class);
        System.out.println("main test " + test.hashCode());
        System.out.println(test.getUserinfo().hashCode());
    }
}
