package com.ghy.www.javaconfig;

import com.ghy.www.entity.Userinfo;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

@Configuration
public class SpringConfig {
    @Bean(name = "userinfo1")
    public Userinfo getUserinfo1() {
        Userinfo userinfo = new Userinfo();
        System.out.println("getUserinfo1 " + userinfo);
        return userinfo;
    }

    @Bean(name = "userinfo2")
    @Lazy(value = true)
    public Userinfo getUserinfo2() {
        Userinfo userinfo = new Userinfo();
        System.out.println("getUserinfo2 " + userinfo);
        return userinfo;
    }
}
