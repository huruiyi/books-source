package com.ghy.www.a.b;

import org.springframework.stereotype.Component;

@Component
public class B {
    public B() {
        System.out.println("public B()");
    }
}