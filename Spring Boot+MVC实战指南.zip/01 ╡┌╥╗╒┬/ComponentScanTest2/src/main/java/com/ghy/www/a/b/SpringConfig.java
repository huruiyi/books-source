package com.ghy.www.a.b;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.Date;

@Configuration
@ComponentScan
public class SpringConfig {
    @Bean
    public Date createDate() {
        Date nowDate = new Date();
        System.out.println("createDate " + nowDate.hashCode());
        return nowDate;
    }
}
