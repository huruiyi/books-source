package com.ghy.www.a.b.c;

import org.springframework.stereotype.Component;

@Component
public class C {
    public C() {
        System.out.println("public C()");
    }
}