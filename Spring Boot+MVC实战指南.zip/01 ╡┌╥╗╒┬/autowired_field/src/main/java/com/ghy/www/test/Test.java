package com.ghy.www.test;

import com.ghy.www.config.SpringConfig;
import com.ghy.www.entity.Bookinfo;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        Bookinfo bookinfo = (Bookinfo) context.getBean(Bookinfo.class);
        System.out.println(bookinfo.getUserinfo().hashCode());
    }
}
