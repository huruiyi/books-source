package com.ghy.www.aspect;

import java.util.Arrays;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AspectObject {

    @Before(value = "execution(* com.ghy.www.service.UserinfoService.*(..))")
    public void before(JoinPoint point) {
        Signature signature = point.getSignature();
        System.out.println("public void before()" + " 对象：" + point.getThis() + " 方法：" + signature.getName() + " 参数："
                + Arrays.toString(point.getArgs()));
    }

    @After(value = "execution(* com.ghy.www.service.UserinfoService.*(..))")
    public void after(JoinPoint point) {
        Signature signature = point.getSignature();
        System.out.println("public void after()" + " 对象：" + point.getThis() + " 方法：" + signature.getName() + " 参数："
                + Arrays.toString(point.getArgs()));
    }

    @AfterReturning(value = "execution(* com.ghy.www.service.UserinfoService.*(..))")
    public void afterReturning(JoinPoint point) {
        Signature signature = point.getSignature();
        System.out.println("public void afterReturning()" + " 对象：" + point.getThis() + " 方法：" + signature.getName()
                + " 参数：" + Arrays.toString(point.getArgs()));
    }

    @AfterThrowing(value = "execution(* com.ghy.www.service.UserinfoService.*(..))")
    public void afterThrowing(JoinPoint point) {
        Signature signature = point.getSignature();
        System.out.println("public void afterThrowing()" + " 对象：" + point.getThis() + " 方法：" + signature.getName()
                + " 参数：" + Arrays.toString(point.getArgs()));
    }

}
