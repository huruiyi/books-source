package com.ghy.www.test;

import com.ghy.www.config.SpringConfig;
import com.ghy.www.service.UserinfoService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        UserinfoService service = (UserinfoService) context.getBean(UserinfoService.class);
        service.method1();
        System.out.println();
        System.out.println();
        System.out.println("main get method2 returnValue=" + service.method2());
        System.out.println();
        System.out.println();
        System.out.println("main get method3 returnValue=" + service.method3());
    }
}

