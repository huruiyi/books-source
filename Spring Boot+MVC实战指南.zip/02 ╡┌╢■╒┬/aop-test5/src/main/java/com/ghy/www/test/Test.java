package com.ghy.www.test;

import com.ghy.www.handler.MyMethodHandler;
import com.ghy.www.service.UserinfoService;
import javassist.util.proxy.Proxy;
import javassist.util.proxy.ProxyFactory;

public class Test {
    public static void main(String[] args) throws InstantiationException, IllegalAccessException {
        ProxyFactory proxyFactory = new ProxyFactory();
        proxyFactory.setSuperclass(UserinfoService.class);

        Class classRef = proxyFactory.createClass();
        UserinfoService service = (UserinfoService) classRef.newInstance();
        ((Proxy) service).setHandler(new MyMethodHandler(new UserinfoService()));
        service.save();
    }
}

