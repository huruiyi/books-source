package com.ghy.www.handler;
import java.lang.reflect.Method;

import javassist.util.proxy.MethodHandler;

public class MyMethodHandler implements MethodHandler {
    private Object object;

    public MyMethodHandler(Object object) {
        super();
        this.object = object;
    }

    @Override
    public Object invoke(Object arg0, Method arg1, Method arg2, Object[] arg3) throws Throwable {
        System.out.println("begin");
        Object returnValue = arg1.invoke(object, arg3);
        System.out.println("  end");
        return returnValue;
    }

}

