package com.ghy.www.test;

import com.ghy.www.proxy.SFBookProxy;
import com.ghy.www.service.DangDangBook;
import com.ghy.www.service.ISendBook;
import com.ghy.www.service.JDBook;

public class Test {
    public static void main(String[] args) {
        JDBook jdBook = new JDBook();
        DangDangBook dangdangBook = new DangDangBook();

        ISendBook sf1 = new SFBookProxy(jdBook);
        sf1.sendBook();

        System.out.println();

        ISendBook sf2 = new SFBookProxy(dangdangBook);
        sf2.sendBook();
    }

}
