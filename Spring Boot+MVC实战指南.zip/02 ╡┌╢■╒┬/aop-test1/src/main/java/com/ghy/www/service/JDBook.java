package com.ghy.www.service;

public class JDBook implements ISendBook {
    @Override
    public void sendBook() {
        System.out.println("JD书籍部门知道你的地址，电话，备注，准备进行配送！");
    }
}
