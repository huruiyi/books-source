package com.ghy.www.service;

public class DangDangBook implements ISendBook {
    @Override
    public void sendBook() {
        System.out.println("当当网书籍部门知道你的地址，电话，备注，准备进行配送！");
    }
}
