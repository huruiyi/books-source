package com.ghy.www.service;

public interface IUserinfoService {
    void method1();

    String method2();

    String method3();
}
