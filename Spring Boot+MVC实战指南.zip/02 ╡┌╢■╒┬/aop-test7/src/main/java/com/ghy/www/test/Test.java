package com.ghy.www.test;

import com.ghy.www.config.SpringConfig;
import com.ghy.www.service.IUserinfoService;
import com.ghy.www.service.UserinfoService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        IUserinfoService service1 = (IUserinfoService) context.getBean("userinfoService");
        System.out.println("service1=" + service1);
        IUserinfoService service2 = (IUserinfoService) context.getBean(UserinfoService.class);
    }
}

