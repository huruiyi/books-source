package com.ghy.www.service;

import org.springframework.stereotype.Service;

@Service
public class UserinfoService implements IUserinfoService {
    @Override
    public void method1() {
        System.out.println("method1 run !");
    }

    @Override
    public String method2() {
        System.out.println("method2 run !");
        return "我是返回值A";
    }

    @Override
    public String method3() {
        System.out.println("method3 run !");
        Integer.parseInt("a");
        return "我是返回值B";
    }
}

