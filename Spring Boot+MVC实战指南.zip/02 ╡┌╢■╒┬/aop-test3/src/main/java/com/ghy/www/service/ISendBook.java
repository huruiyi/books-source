package com.ghy.www.service;

public interface ISendBook {
    public void sendBook();
    public void sendBookError();
}
