package com.ghy.www.test;

import com.ghy.www.hanlder.LogInvocationHandler;
import com.ghy.www.service.DangDangBook;
import com.ghy.www.service.ISendBook;
import com.ghy.www.service.JDBook;

import java.lang.reflect.Proxy;

public class Test {
    public static void main(String[] args) {
        DangDangBook dangdangBook = new DangDangBook();
        JDBook jdBook = new JDBook();
        {
            LogInvocationHandler handler = new LogInvocationHandler(dangdangBook);
            ISendBook sendBook = (ISendBook) Proxy.newProxyInstance(Test.class.getClassLoader(),
                    dangdangBook.getClass().getInterfaces(), handler);
            sendBook.sendBook();
        }
        System.out.println();
        {
            LogInvocationHandler handler = new LogInvocationHandler(jdBook);
            ISendBook sendBook = (ISendBook) Proxy.newProxyInstance(Test.class.getClassLoader(),
                    dangdangBook.getClass().getInterfaces(), handler);
            sendBook.sendBook();
        }
    }
}
