package com.ghy.www.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Aspect
@Order(value = 3)
public class AspectObject1 {
    @Around(value = "execution(* com.ghy.www.service.UserinfoService.*(..))")
    public Object around(ProceedingJoinPoint point) {
        Object returnObject = null;
        try {
            System.out.println("开始1");
            returnObject = point.proceed();
            System.out.println("结束1");
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return returnObject;
    }
}
