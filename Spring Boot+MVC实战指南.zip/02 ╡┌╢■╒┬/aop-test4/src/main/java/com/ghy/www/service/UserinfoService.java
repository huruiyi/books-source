package com.ghy.www.service;

public class UserinfoService {
    public void save() {
        System.out.println("将数据保存到数据库！");
    }
}

