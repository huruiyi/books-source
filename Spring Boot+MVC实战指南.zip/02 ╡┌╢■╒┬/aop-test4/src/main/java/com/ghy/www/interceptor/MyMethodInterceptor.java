package com.ghy.www.interceptor;

import net.sf.cglib.proxy.MethodInterceptor;
import net.sf.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

public class MyMethodInterceptor implements MethodInterceptor {
    private Object object;

    public MyMethodInterceptor(Object object) {
        super();
        this.object = object;
    }

    @Override
    public Object intercept(Object arg0, Method arg1, Object[] arg2, MethodProxy arg3) throws Throwable {
        System.out.println("begin");
        Object returnValue = arg1.invoke(object, arg2);
        System.out.println("  end");
        return returnValue;
    }

}
