package com.ghy.www.test;

import com.ghy.www.interceptor.MyMethodInterceptor;
import com.ghy.www.service.UserinfoService;
import net.sf.cglib.proxy.Enhancer;

public class Test {
    public static void main(String[] args) {
        // Enhancer类是cglib中的增强工具类
        Enhancer enhancer = new Enhancer();
        // cglib使用继承原理来实现代理，所以要设置父类
        enhancer.setSuperclass(UserinfoService.class);
        // 设置回调对象
        enhancer.setCallback(new MyMethodInterceptor(new UserinfoService()));
        // 创建代理对象
        UserinfoService service = (UserinfoService) enhancer.create();
        // 调用代理对象中的业务方法
        service.save();
    }
}

