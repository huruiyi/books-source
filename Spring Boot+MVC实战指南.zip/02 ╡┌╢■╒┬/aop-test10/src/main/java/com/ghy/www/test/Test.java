package com.ghy.www.test;

import com.ghy.www.config.SpringConfig;
import com.ghy.www.service.UserinfoServiceA;
import com.ghy.www.service.UserinfoServiceB;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);
        UserinfoServiceA serviceA = (UserinfoServiceA) context.getBean(UserinfoServiceA.class);
        serviceA.method1();
        System.out.println();
        UserinfoServiceB serviceB = (UserinfoServiceB) context.getBean(UserinfoServiceB.class);
        serviceB.method1();
    }
}

