package com.ghy.www.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class AspectObject2 {
    @Around(value = "execution(* com.ghy.www.service.UserinfoService.*(..))")
    public Object around(ProceedingJoinPoint point) {
        Object returnObject = null;
        try {
            System.out.println("开始2");
            returnObject = point.proceed();
            System.out.println("结束2");
        } catch (Throwable e) {
            e.printStackTrace();
        }
        return returnObject;
    }
}
