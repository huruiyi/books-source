package com.ghy.www.aspect;

import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
@Aspect
public class AspectObject {
    @Pointcut(value = "execution(* com.ghy.www.service.UserinfoService.method1(int)) && args(xxxxxx)")
    public void methodAspect1(int xxxxxx) {
    }

    @Before(value = "methodAspect1(ageabc)")
    public void method1Before(int ageabc) {
        System.out.println("切面：public void method1Before(int ageabc) ageabc=" + ageabc);
    }

    //

    @Pointcut(value = "execution(* com.ghy.www.service.UserinfoService.method2(String,String,int,java.util.Date)) && args(u,p,a,i)")
    public void methodAspect2(String u, String p, int a, Date i) {
    }

    @Before(value = "methodAspect2(uu,pp,aa,ii)")
    public void method2Before(String uu, String pp, int aa, Date ii) {
        System.out.println("切面：public void method2Before(String uu, String pp, int aa, Date ii) uu=" + uu + " pp=" + pp
                + " aa=" + aa + " ii=" + ii);
    }
}

