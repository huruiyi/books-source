package com.ghy.www.test;

import com.ghy.www.service.DangDangBook;
import sun.misc.ProxyGenerator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class Test1 {
    public static void main(String[] args) throws IOException {
        DangDangBook dangdangBook = new DangDangBook();
        byte[] proxyClassFile = ProxyGenerator.generateProxyClass(
                "$Proxy0", dangdangBook.getClass().getInterfaces());
        FileOutputStream fileOutputStream = new FileOutputStream(new File("c:\\abc\\$Proxy0.class"));
        fileOutputStream.write(proxyClassFile);
        fileOutputStream.flush();
        fileOutputStream.close();
    }
}
