package com.ghy.www.test;

public class Test4 {
    public static void main(String[] args) {
        Object o = null;
        int intValue = (Integer) o;
        System.out.println(intValue);
    }
}
