package com.ghy.www.test;

import com.ghy.www.hanlder.LogInvocationHandler;
import com.ghy.www.service.DangDangBook;
import com.ghy.www.service.ISendBook;

import java.lang.reflect.Proxy;

public class Test2 {
    public static void main(String[] args) {
        DangDangBook dangdangBook = new DangDangBook();
        LogInvocationHandler handler = new LogInvocationHandler(dangdangBook);
        ISendBook sendBook = (ISendBook) Proxy.newProxyInstance(Test2.class.getClassLoader(),
                dangdangBook.getClass().getInterfaces(), handler);
        System.out.println(sendBook.toString());
    }
}
