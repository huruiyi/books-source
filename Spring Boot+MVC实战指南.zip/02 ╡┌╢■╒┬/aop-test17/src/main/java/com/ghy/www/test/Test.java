package com.ghy.www.test;

import com.ghy.www.handler.MyLogHandler;
import com.ghy.www.handler.MyRunTimeHandler;
import com.ghy.www.servicebook.DangDangBookService;
import com.ghy.www.servicebook.ISendBook;

import java.lang.reflect.Proxy;

public class Test {
    public static void main(String[] args) {
        ISendBook dangdangBook = new DangDangBookService();

        ClassLoader classLoader = Test.class.getClassLoader();
        Class<?>[] interfaces = dangdangBook.getClass().getInterfaces();
        MyRunTimeHandler handler1 = new MyRunTimeHandler(dangdangBook);

        ISendBook iSendBook1 = (ISendBook) Proxy.newProxyInstance(classLoader, interfaces, handler1);
        MyLogHandler handler2 = new MyLogHandler(iSendBook1);

        ISendBook iSendBook2 = (ISendBook) Proxy.newProxyInstance(classLoader, interfaces, handler2);
        iSendBook2.sendBook();
    }
}
