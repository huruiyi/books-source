package com.ghy.www.handler;

import com.ghy.www.servicebook.ISendBook;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class MyLogHandler implements InvocationHandler {

    private ISendBook who;

    public MyLogHandler(ISendBook who) {
        this.who = who;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        System.out.println("begin log");
        method.invoke(who, args);
        long endTime = System.currentTimeMillis();
        System.out.println("  end log");
        return null;
    }
}
