package com.ghy.www.servicebook;

public class JDBookService implements  ISendBook{
    @Override
    public void sendBook() {
        System.out.println("京东知道下单者的信息(姓名，电话，地址，等等！)");
    }
}
