package com.ghy.www.servicebook;

public interface ISendBook {
    public void sendBook();
}
