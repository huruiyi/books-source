package com.ghy.www.handler;

import com.ghy.www.servicebook.ISendBook;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class MyRunTimeHandler implements InvocationHandler {

    private ISendBook who;

    public MyRunTimeHandler(ISendBook who) {
        this.who = who;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        long beginTime = System.currentTimeMillis();
        System.out.println("beginTime=" + beginTime + " methodName=" + method.getName());
        //对who对象调用method方法，如果方法有参，则传入args
        method.invoke(who, args);
        long endTime = System.currentTimeMillis();
        System.out.println("  endTime=" + endTime + " run time =" + (endTime - beginTime));
        return null;
    }
}
