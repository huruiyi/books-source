package com.ghy.www.servicebook;

public class DangDangBookService implements ISendBook {
    @Override
    public void sendBook() {
        //只负责接收下单，保存订单，商品展示
        System.out.println("当当知道下单者的信息(姓名，电话，地址，等等！)");
    }
}
