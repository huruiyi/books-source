﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionInterface
{
    public interface IExtension
    {
        int Execute(int arg1, int arg2);
    }
}
