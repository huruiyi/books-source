﻿
namespace DynamicLoadExtension
{
    public class Extension
    {
        public bool DoWork(string numberString)
        {
            // Commented out so you can see the difference in function call overhead

            //Int64 number = Int64.Parse(numberString);
            //Math.Sqrt(number);
            return true;
        }
    }
}
