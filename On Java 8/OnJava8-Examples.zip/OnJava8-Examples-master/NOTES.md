For generating table of contents in README.md
https://ecotrust-canada.github.io/markdown-toc/
(Replace double hyphens with single hyphens after generation)
