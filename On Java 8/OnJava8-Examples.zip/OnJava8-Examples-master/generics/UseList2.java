// generics/UseList2.java
// (c)2021 MindView LLC: see Copyright.txt
// We make no guarantees that this code is fit for any purpose.
// Visit http://OnJava8.com for more book information.
import java.util.*;

public class UseList2<W, T> {
  void f1(List<T> v) {}
  void f2(List<W> v) {}
}
