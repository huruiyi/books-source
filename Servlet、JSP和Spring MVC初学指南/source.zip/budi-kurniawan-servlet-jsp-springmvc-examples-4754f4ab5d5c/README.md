# Servlet, JSP and Spring MVC: A Tutorial #
### By: Budi Kurniawan and Paul Deck ###
### ISBN: 9781771970020 ###
### Published by Brainy Software (http://brainysoftware.com) ###
### If you are not familiar with GIT, download the zip by clicking the "Downloads" link on the left menu ###
### ###
### Each Servlet/JSP example comes with compiled Java classes so you can easily deploy the app to Tomcat or Jetty. ###
### The dependencies in chapters 15..24 examples have been deleted to save space. To setup the projects, copy all the jar files in the lib directory (except servlet-api.jar and jsp-api.jar) to each project's WEB-INF/lib directory ###