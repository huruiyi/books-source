package com.smart.exception;

public class BusException extends RuntimeException {

}
