package com.smart.web;

public class NotLoginException extends RuntimeException{
}
