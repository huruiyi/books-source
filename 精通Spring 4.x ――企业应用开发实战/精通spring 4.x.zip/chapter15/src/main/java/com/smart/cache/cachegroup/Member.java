package com.smart.cache.cachegroup;

import com.smart.cache.domain.User;

public class Member extends User {
    public Member(String id, String name) {
        super(id, name);
    }
}
