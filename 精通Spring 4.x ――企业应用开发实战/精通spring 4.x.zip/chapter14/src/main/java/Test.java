import java.util.ArrayList;
import java.util.List;


public class Test extends Base<String> {
   
	public static void main(String[] args) {
//		Test t = new Test();
//		List<String> ls = t.getEntity(String.class, 1);
//		for (String string : ls) {
//			System.out.println("str:"+string);
//		}
//		List<String> ls = new ArrayList();
//		ls.add("d");
		List<Object> lo = new ArrayList<Object>();	
		List<String> ls = new ArrayList<String>();
//		lo = ls;//<---此外语法编译不过	
	}
}
