package com.smart.nestcall;

/**
 * @author 陈雄华
 * @version 1.0
 */
public class BaseService {
}
