/**
 * Sample软件公司, 版权所有 违者必究
 * Copyright 2010 
 * 2010-2-20
 */
package com.smart.special;

/**
 * @author 陈雄华
 * @version 1.0
 */
public interface UserServiceInterface {
    void method4();
    void method5();
}
